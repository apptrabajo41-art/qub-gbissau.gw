import { useEffect, useRef, useState } from 'react';
import { MapPin, Phone, Mail, Clock, Send, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const Contact = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });

  const contactInfo = [
    {
      icon: MapPin,
      title: 'Endereço',
      content: 'Av. dos Combatentes da Liberdade, Bissau, Guiné-Bissau',
    },
    {
      icon: Phone,
      title: 'Telefone',
      content: '+245 956 990 388 / 965 397 777 / 956 990 389',
    },
    {
      icon: Mail,
      title: 'Email',
      content: 'communications.afrique@cgi.ci',
    },
    {
      icon: Clock,
      title: 'Horário',
      content: 'Segunda a Sexta: 8h - 17h',
    },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
    setTimeout(() => {
      setIsSubmitted(false);
      setFormData({ name: '', email: '', subject: '', message: '' });
    }, 3000);
  };

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Title animation
      gsap.fromTo(
        '.contact-title',
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );

      // Contact info items
      gsap.fromTo(
        '.contact-info-item',
        { x: -30, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.5,
          stagger: 0.1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: '.contact-info-container',
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );

      // Form card
      gsap.fromTo(
        '.contact-form-card',
        { scale: 0.95, opacity: 0 },
        {
          scale: 1,
          opacity: 1,
          duration: 0.6,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: '.contact-form-card',
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );

      // Form fields
      gsap.fromTo(
        '.form-field',
        { y: 20, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.4,
          stagger: 0.1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: '.contact-form-card',
            start: 'top 75%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="contact"
      ref={sectionRef}
      className="relative py-20 sm:py-28 bg-white overflow-hidden"
    >
      {/* Background Decorations */}
      <div className="absolute inset-0 pointer-events-none">
        <div
          className="absolute top-0 left-0 w-[400px] h-[400px] rounded-full blur-3xl opacity-15"
          style={{
            background: 'radial-gradient(circle, rgba(34,139,34,0.3) 0%, transparent 70%)',
          }}
        />
        <div
          className="absolute bottom-0 right-0 w-[300px] h-[300px] rounded-full blur-3xl opacity-15"
          style={{
            background: 'radial-gradient(circle, rgba(255,215,0,0.3) 0%, transparent 70%)',
          }}
        />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span
            className="inline-block text-sm font-semibold text-[#228B22] uppercase tracking-wider mb-4"
            style={{ fontFamily: 'Montserrat, sans-serif' }}
          >
            Fale Connosco
          </span>
          <h2
            className="contact-title text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-800 mb-4"
            style={{ fontFamily: 'Montserrat, sans-serif' }}
          >
            Entre em <span className="text-gradient-qub">Contacto</span>
          </h2>
          <p className="contact-title text-gray-600 max-w-2xl mx-auto text-base sm:text-lg">
            Estamos aqui para ajudar. Envie-nos uma mensagem e responderemos o mais breve possível.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-12 lg:gap-16">
          {/* Contact Info */}
          <div className="contact-info-container lg:col-span-2">
            <div className="space-y-6">
              {contactInfo.map((item) => (
                <div
                  key={item.title}
                  className="contact-info-item flex items-start gap-4 p-4 rounded-xl hover:bg-gray-50 transition-colors duration-300 group"
                >
                  <div className="w-12 h-12 relative flex items-center justify-center flex-shrink-0">
                    <svg viewBox="0 0 48 48" className="absolute inset-0 w-full h-full">
                      <polygon
                        points="24,4 44,14 44,34 24,44 4,34 4,14"
                        fill="#228B22"
                        fillOpacity="0.1"
                        stroke="#228B22"
                        strokeWidth="1.5"
                        className="transition-all duration-300 group-hover:fill-opacity-20"
                      />
                    </svg>
                    <item.icon className="w-5 h-5 relative z-10 text-[#228B22] transition-transform duration-300 group-hover:scale-110" />
                  </div>
                  <div>
                    <h4
                      className="font-semibold text-gray-800 mb-1"
                      style={{ fontFamily: 'Montserrat, sans-serif' }}
                    >
                      {item.title}
                    </h4>
                    <p className="text-gray-600 text-sm">{item.content}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Map Placeholder */}
            <div className="mt-8 rounded-2xl overflow-hidden shadow-lg">
              <div className="aspect-video bg-gradient-to-br from-[#228B22]/10 to-[#FFD700]/10 flex items-center justify-center">
                <div className="text-center">
                  <MapPin className="w-12 h-12 text-[#228B22] mx-auto mb-2" />
                  <p className="text-gray-600 text-sm">Bissau, Guiné-Bissau</p>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="contact-form-card lg:col-span-3 bg-white rounded-2xl shadow-xl p-6 sm:p-8 lg:p-10">
            {isSubmitted ? (
              <div className="flex flex-col items-center justify-center h-full py-12">
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mb-6">
                  <CheckCircle className="w-10 h-10 text-green-600" />
                </div>
                <h3
                  className="text-2xl font-bold text-gray-800 mb-2"
                  style={{ fontFamily: 'Montserrat, sans-serif' }}
                >
                  Mensagem Enviada!
                </h3>
                <p className="text-gray-600 text-center">
                  Obrigado pelo contacto. Responderemos em breve.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div className="form-field">
                    <label
                      htmlFor="name"
                      className="block text-sm font-medium text-gray-700 mb-2"
                      style={{ fontFamily: 'Montserrat, sans-serif' }}
                    >
                      Nome
                    </label>
                    <Input
                      id="name"
                      type="text"
                      placeholder="Seu nome completo"
                      value={formData.name}
                      onChange={(e) =>
                        setFormData({ ...formData, name: e.target.value })
                      }
                      required
                      className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-[#228B22] focus:ring-2 focus:ring-[#228B22]/20 transition-all duration-200"
                    />
                  </div>
                  <div className="form-field">
                    <label
                      htmlFor="email"
                      className="block text-sm font-medium text-gray-700 mb-2"
                      style={{ fontFamily: 'Montserrat, sans-serif' }}
                    >
                      Email
                    </label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="seu@email.com"
                      value={formData.email}
                      onChange={(e) =>
                        setFormData({ ...formData, email: e.target.value })
                      }
                      required
                      className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-[#228B22] focus:ring-2 focus:ring-[#228B22]/20 transition-all duration-200"
                    />
                  </div>
                </div>

                <div className="form-field">
                  <label
                    htmlFor="subject"
                    className="block text-sm font-medium text-gray-700 mb-2"
                    style={{ fontFamily: 'Montserrat, sans-serif' }}
                  >
                    Assunto
                  </label>
                  <Select
                    value={formData.subject}
                    onValueChange={(value) =>
                      setFormData({ ...formData, subject: value })
                    }
                  >
                    <SelectTrigger className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-[#228B22] focus:ring-2 focus:ring-[#228B22]/20">
                      <SelectValue placeholder="Selecione um assunto" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="matricula">Matrícula de Veículos</SelectItem>
                      <SelectItem value="carta">Carta de Condução</SelectItem>
                      <SelectItem value="documentos">Documentos Biométricos</SelectItem>
                      <SelectItem value="duvidas">Dúvidas Gerais</SelectItem>
                      <SelectItem value="outro">Outro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="form-field">
                  <label
                    htmlFor="message"
                    className="block text-sm font-medium text-gray-700 mb-2"
                    style={{ fontFamily: 'Montserrat, sans-serif' }}
                  >
                    Mensagem
                  </label>
                  <Textarea
                    id="message"
                    placeholder="Escreva sua mensagem..."
                    value={formData.message}
                    onChange={(e) =>
                      setFormData({ ...formData, message: e.target.value })
                    }
                    required
                    rows={5}
                    className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-[#228B22] focus:ring-2 focus:ring-[#228B22]/20 transition-all duration-200 resize-none"
                  />
                </div>

                <Button
                  type="submit"
                  className="form-field w-full bg-[#228B22] hover:bg-[#1A6B1A] text-white py-4 rounded-full text-base font-semibold transition-all duration-300 hover:scale-[1.02] hover:shadow-xl group"
                  style={{ fontFamily: 'Montserrat, sans-serif' }}
                >
                  Enviar Mensagem
                  <Send className="ml-2 w-5 h-5 transition-transform group-hover:translate-x-1" />
                </Button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
