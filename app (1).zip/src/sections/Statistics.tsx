import { useEffect, useRef, useState } from 'react';
import { Briefcase, Users, Clock, ThumbsUp } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface StatItemProps {
  icon: React.ElementType;
  value: string;
  label: string;
  suffix?: string;
  delay: number;
}

const StatItem = ({ icon: Icon, value, label, suffix = '', delay }: StatItemProps) => {
  const [count, setCount] = useState(0);
  const itemRef = useRef<HTMLDivElement>(null);
  const numericValue = parseInt(value.replace(/\D/g, ''), 10);
  const hasStarted = useRef(false);

  useEffect(() => {
    const ctx = gsap.context(() => {
      ScrollTrigger.create({
        trigger: itemRef.current,
        start: 'top 85%',
        onEnter: () => {
          if (hasStarted.current) return;
          hasStarted.current = true;

          // Animate the container
          gsap.fromTo(
            itemRef.current,
            { scale: 0.5, opacity: 0 },
            {
              scale: 1,
              opacity: 1,
              duration: 0.8,
              delay,
              ease: 'back.out(1.7)',
            }
          );

          // Counter animation
          const duration = 1500;
          const startTime = Date.now();

          const animate = () => {
            const elapsed = Date.now() - startTime;
            const progress = Math.min(elapsed / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 3); // ease-out cubic
            setCount(Math.floor(eased * numericValue));

            if (progress < 1) {
              requestAnimationFrame(animate);
            }
          };

          setTimeout(() => {
            requestAnimationFrame(animate);
          }, delay * 1000);
        },
      });
    }, itemRef);

    return () => ctx.revert();
  }, [delay, numericValue]);

  const displayValue = value.includes('M')
    ? `${count}M`
    : value.includes('%')
    ? `${count}%`
    : value.includes('/')
    ? value
    : `${count}${suffix}`;

  return (
    <div
      ref={itemRef}
      className="stat-item text-center text-white opacity-0"
    >
      <div className="flex justify-center mb-4">
        <div className="w-16 h-16 relative flex items-center justify-center">
          <svg viewBox="0 0 64 64" className="absolute inset-0 w-full h-full">
            <polygon
              points="32,4 60,18 60,46 32,60 4,46 4,18"
              fill="rgba(255,255,255,0.1)"
              stroke="rgba(255,255,255,0.3)"
              strokeWidth="1.5"
            />
          </svg>
          <Icon className="w-7 h-7 relative z-10 text-white" />
        </div>
      </div>
      <div
        className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-2 animate-pulse-subtle"
        style={{ fontFamily: 'Montserrat, sans-serif' }}
      >
        {displayValue}
      </div>
      <div className="text-sm sm:text-base text-white/80">{label}</div>
    </div>
  );
};

const Statistics = () => {
  const sectionRef = useRef<HTMLDivElement>(null);

  const stats = [
    {
      icon: Briefcase,
      value: '50',
      label: 'Serviços Digitalizados',
      suffix: '+',
    },
    {
      icon: Users,
      value: '1',
      label: 'Cidadãos Atendidos',
      suffix: 'M+',
    },
    {
      icon: Clock,
      value: '24/7',
      label: 'Disponibilidade',
    },
    {
      icon: ThumbsUp,
      value: '99',
      label: 'Satisfação dos Usuários',
      suffix: '%',
    },
  ];

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Background animation
      gsap.fromTo(
        sectionRef.current,
        { opacity: 0 },
        {
          opacity: 1,
          duration: 0.6,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative py-16 sm:py-24 overflow-hidden"
      style={{
        background: 'linear-gradient(135deg, #228B22 0%, #1A6B1A 100%)',
      }}
    >
      {/* Hexagonal Pattern Overlay */}
      <div className="absolute inset-0 opacity-10">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern
              id="statsHexPattern"
              x="0"
              y="0"
              width="60"
              height="52"
              patternUnits="userSpaceOnUse"
            >
              <polygon
                points="30,2 58,15 58,37 30,50 2,37 2,15"
                fill="none"
                stroke="white"
                strokeWidth="0.5"
              />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#statsHexPattern)" />
        </svg>
      </div>

      {/* Animated Gradient Overlay */}
      <div
        className="absolute inset-0 opacity-30 animate-gradient-shift"
        style={{
          background: 'linear-gradient(45deg, transparent 0%, rgba(255,215,0,0.1) 50%, transparent 100%)',
          backgroundSize: '400% 400%',
        }}
      />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          {stats.map((stat, index) => (
            <StatItem key={stat.label} {...stat} delay={index * 0.2} />
          ))}
        </div>
      </div>

      {/* Decorative Elements */}
      <div className="absolute top-0 left-0 w-32 h-32 opacity-10">
        <svg viewBox="0 0 128 128" className="w-full h-full">
          <polygon
            points="64,8 120,36 120,92 64,120 8,92 8,36"
            fill="none"
            stroke="white"
            strokeWidth="1"
          />
        </svg>
      </div>
      <div className="absolute bottom-0 right-0 w-24 h-24 opacity-10">
        <svg viewBox="0 0 96 96" className="w-full h-full">
          <polygon
            points="48,8 88,28 88,68 48,88 8,68 8,28"
            fill="none"
            stroke="white"
            strokeWidth="1"
          />
        </svg>
      </div>
    </section>
  );
};

export default Statistics;
