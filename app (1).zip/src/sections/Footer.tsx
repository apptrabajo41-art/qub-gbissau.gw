import { useEffect, useRef } from 'react';
import { Facebook, Twitter, Instagram, Linkedin, ExternalLink } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const Footer = () => {
  const footerRef = useRef<HTMLDivElement>(null);

  const quickLinks = [
    { name: 'Início', href: '#hero' },
    { name: 'Serviços', href: '#services' },
    { name: 'Sobre', href: '#about' },
    { name: 'Contactos', href: '#contact' },
    { name: 'Área do Cidadão', href: '#' },
  ];

  const services = [
    'Sistema de Gestão',
    'Matrícula de Veículos',
    'Carta de Condução',
    'Documentos Biométricos',
    'Balcão Único',
  ];

  const socialLinks = [
    { icon: Facebook, href: '#', label: 'Facebook' },
    { icon: Twitter, href: '#', label: 'Twitter' },
    { icon: Instagram, href: '#', label: 'Instagram' },
    { icon: Linkedin, href: '#', label: 'LinkedIn' },
  ];

  const scrollToSection = (href: string) => {
    if (href === '#') return;
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Footer entrance
      gsap.fromTo(
        footerRef.current,
        { opacity: 0 },
        {
          opacity: 1,
          duration: 0.6,
          scrollTrigger: {
            trigger: footerRef.current,
            start: 'top 90%',
            toggleActions: 'play none none none',
          },
        }
      );

      // Logo
      gsap.fromTo(
        '.footer-logo',
        { scale: 0.9, opacity: 0 },
        {
          scale: 1,
          opacity: 1,
          duration: 0.5,
          delay: 0.1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: footerRef.current,
            start: 'top 90%',
            toggleActions: 'play none none none',
          },
        }
      );

      // Columns
      gsap.fromTo(
        '.footer-column',
        { y: 20, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.4,
          stagger: 0.1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: footerRef.current,
            start: 'top 85%',
            toggleActions: 'play none none none',
          },
        }
      );

      // Social icons
      gsap.fromTo(
        '.social-icon',
        { scale: 0, opacity: 0 },
        {
          scale: 1,
          opacity: 1,
          duration: 0.3,
          stagger: 0.05,
          ease: 'back.out(1.7)',
          scrollTrigger: {
            trigger: footerRef.current,
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );

      // Bottom bar
      gsap.fromTo(
        '.footer-bottom',
        { y: 20, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.4,
          delay: 0.6,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: footerRef.current,
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, footerRef);

    return () => ctx.revert();
  }, []);

  return (
    <footer
      ref={footerRef}
      className="relative bg-[#228B22] text-white overflow-hidden"
    >
      {/* Hexagonal Pattern Background */}
      <div className="absolute inset-0 opacity-5">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern
              id="footerHexPattern"
              x="0"
              y="0"
              width="50"
              height="43.3"
              patternUnits="userSpaceOnUse"
            >
              <polygon
                points="25,0 50,10.8 50,32.5 25,43.3 0,32.5 0,10.8"
                fill="none"
                stroke="white"
                strokeWidth="0.5"
              />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#footerHexPattern)" />
        </svg>
      </div>

      <div className="relative z-10">
        {/* Main Footer Content */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
            {/* Logo & Description */}
            <div className="footer-column sm:col-span-2 lg:col-span-1">
              <div className="footer-logo flex items-center gap-3 mb-6">
                <div className="w-14 h-14 relative flex items-center justify-center">
                  <svg viewBox="0 0 64 64" className="w-full h-full">
                    <polygon
                      points="32,4 60,18 60,46 32,60 4,46 4,18"
                      fill="none"
                      stroke="white"
                      strokeWidth="2"
                    />
                    <text
                      x="32"
                      y="38"
                      textAnchor="middle"
                      className="text-sm font-bold"
                      fill="white"
                      style={{ fontFamily: 'Montserrat, sans-serif' }}
                    >
                      QUB
                    </text>
                  </svg>
                </div>
                <span
                  className="text-lg font-bold"
                  style={{ fontFamily: 'Montserrat, sans-serif' }}
                >
                  QUIPUX BISSAU
                </span>
              </div>
              <p className="text-white/80 text-sm leading-relaxed mb-6">
                Centro de Serviços Integrados do Ministério dos Transportes e
                Comunicações da Guiné-Bissau.
              </p>

              {/* Social Links */}
              <div className="flex gap-3">
                {socialLinks.map((social) => (
                  <a
                    key={social.label}
                    href={social.href}
                    aria-label={social.label}
                    className="social-icon w-10 h-10 relative flex items-center justify-center rounded-full bg-white/10 hover:bg-white/20 transition-all duration-300 hover:scale-110 group"
                  >
                    <social.icon className="w-5 h-5 text-white" />
                  </a>
                ))}
              </div>
            </div>

            {/* Quick Links */}
            <div className="footer-column">
              <h4
                className="text-lg font-semibold mb-6"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                Links Rápidos
              </h4>
              <ul className="space-y-3">
                {quickLinks.map((link) => (
                  <li key={link.name}>
                    <a
                      href={link.href}
                      onClick={(e) => {
                        e.preventDefault();
                        scrollToSection(link.href);
                      }}
                      className="text-white/80 hover:text-[#FFD700] text-sm transition-all duration-200 hover:translate-x-1 inline-flex items-center gap-1 group"
                    >
                      {link.name}
                      <ExternalLink className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Services */}
            <div className="footer-column">
              <h4
                className="text-lg font-semibold mb-6"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                Serviços
              </h4>
              <ul className="space-y-3">
                {services.map((service) => (
                  <li key={service}>
                    <span className="text-white/80 text-sm">{service}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Contact Info */}
            <div className="footer-column">
              <h4
                className="text-lg font-semibold mb-6"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                Contacto
              </h4>
              <div className="space-y-4">
                <div>
                  <p className="text-white/60 text-xs mb-1">Endereço</p>
                  <p className="text-white/80 text-sm">
                    Av. dos Combatentes da Liberdade
                    <br />
                    Bissau, Guiné-Bissau
                  </p>
                </div>
                <div>
                  <p className="text-white/60 text-xs mb-1">Telefone</p>
                  <p className="text-white/80 text-sm">+245 956 990 388</p>
                </div>
                <div>
                  <p className="text-white/60 text-xs mb-1">Email</p>
                  <p className="text-white/80 text-sm">communications.afrique@cgi.ci</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="footer-bottom border-t border-white/10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <p className="text-white/60 text-sm text-center sm:text-left">
                © {new Date().getFullYear()} QUB - Quipux Bissau. Todos os direitos
                reservados.
              </p>
              <p className="text-white/60 text-sm text-center sm:text-right">
                Governo da Guiné-Bissau - Ministério dos Transportes e Comunicações
              </p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
