import { useEffect, useRef } from 'react';
import { CheckCircle, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const About = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  const stats = [
    { value: '10+', label: 'Anos de Experiência' },
    { value: '50+', label: 'Serviços Digitalizados' },
    { value: '1M+', label: 'Cidadãos Atendidos' },
  ];

  const features = [
    'Tecnologia de ponta para segurança dos dados',
    'Processos simplificados e ágeis',
    'Atendimento integrado 24/7',
    'Compromisso com a transparência',
  ];

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Image animation
      gsap.fromTo(
        imageRef.current,
        { scale: 0.5, rotation: -30, opacity: 0 },
        {
          scale: 1,
          rotation: 0,
          opacity: 1,
          duration: 1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
            toggleActions: 'play none none none',
          },
        }
      );

      // Content animations
      gsap.fromTo(
        '.about-label',
        { x: -30, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.5,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: contentRef.current,
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );

      gsap.fromTo(
        '.about-title span',
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          stagger: 0.1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: contentRef.current,
            start: 'top 75%',
            toggleActions: 'play none none none',
          },
        }
      );

      gsap.fromTo(
        '.about-text',
        { y: 20, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.5,
          stagger: 0.2,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: contentRef.current,
            start: 'top 70%',
            toggleActions: 'play none none none',
          },
        }
      );

      gsap.fromTo(
        '.about-feature',
        { x: -20, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.4,
          stagger: 0.1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: contentRef.current,
            start: 'top 65%',
            toggleActions: 'play none none none',
          },
        }
      );

      // Stats counter animation
      gsap.fromTo(
        '.stat-item',
        { scale: 0.8, opacity: 0 },
        {
          scale: 1,
          opacity: 1,
          duration: 0.6,
          stagger: 0.15,
          ease: 'back.out(1.7)',
          scrollTrigger: {
            trigger: '.stats-container',
            start: 'top 85%',
            toggleActions: 'play none none none',
          },
        }
      );

      // Floating hexagons
      gsap.to('.floating-hex-about', {
        y: '+=20',
        duration: 3,
        ease: 'sine.inOut',
        yoyo: true,
        repeat: -1,
        stagger: {
          each: 0.5,
          from: 'random',
        },
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="about"
      ref={sectionRef}
      className="relative py-20 sm:py-28 bg-[#f8faf8] overflow-hidden"
    >
      {/* Background Decorations */}
      <div className="absolute inset-0 pointer-events-none">
        <div
          className="absolute top-20 left-10 w-[300px] h-[300px] rounded-full blur-3xl opacity-20"
          style={{
            background: 'radial-gradient(circle, rgba(34,139,34,0.3) 0%, transparent 70%)',
          }}
        />
        <div
          className="absolute bottom-20 right-10 w-[250px] h-[250px] rounded-full blur-3xl opacity-20"
          style={{
            background: 'radial-gradient(circle, rgba(255,215,0,0.3) 0%, transparent 70%)',
          }}
        />
      </div>

      {/* Floating Hexagons */}
      <div className="floating-hex-about absolute left-[5%] top-[15%] w-16 h-16 hidden lg:block">
        <svg viewBox="0 0 64 64" className="w-full h-full">
          <polygon
            points="32,4 60,18 60,46 32,60 4,46 4,18"
            fill="none"
            stroke="#228B22"
            strokeWidth="1"
            strokeOpacity="0.3"
          />
        </svg>
      </div>
      <div className="floating-hex-about absolute right-[8%] top-[25%] w-12 h-12 hidden lg:block">
        <svg viewBox="0 0 48 48" className="w-full h-full">
          <polygon
            points="24,4 44,14 44,34 24,44 4,34 4,14"
            fill="#FFD700"
            fillOpacity="0.2"
          />
        </svg>
      </div>
      <div className="floating-hex-about absolute left-[8%] bottom-[20%] w-14 h-14 hidden lg:block">
        <svg viewBox="0 0 56 56" className="w-full h-full">
          <polygon
            points="28,4 52,16 52,40 28,52 4,40 4,16"
            fill="none"
            stroke="#DC143C"
            strokeWidth="1"
            strokeOpacity="0.25"
          />
        </svg>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Image Side */}
          <div ref={imageRef} className="relative order-2 lg:order-1">
            <div className="relative max-w-md mx-auto lg:mx-0">
              {/* Main Hexagonal Image Container */}
              <div className="relative aspect-square">
                {/* Hexagon Border */}
                <div className="absolute inset-0 hexagon-clip bg-gradient-to-br from-[#228B22] via-[#FFD700] to-[#DC143C] p-1">
                  <div className="w-full h-full hexagon-clip bg-white">
                    <img
                      src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800&h=800&fit=crop"
                      alt="Modern government building"
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>

                {/* Decorative Elements */}
                <div className="absolute -top-4 -right-4 w-20 h-20">
                  <svg viewBox="0 0 80 80" className="w-full h-full animate-spin-slow">
                    <polygon
                      points="40,8 72,24 72,56 40,72 8,56 8,24"
                      fill="none"
                      stroke="#228B22"
                      strokeWidth="1.5"
                      strokeOpacity="0.3"
                    />
                  </svg>
                </div>

                <div className="absolute -bottom-6 -left-6 w-24 h-24">
                  <svg viewBox="0 0 96 96" className="w-full h-full">
                    <polygon
                      points="48,8 88,28 88,68 48,88 8,68 8,28"
                      fill="#FFD700"
                      fillOpacity="0.15"
                    />
                  </svg>
                </div>
              </div>

              {/* Stats Card */}
              <div className="stats-container absolute -bottom-8 -right-4 lg:right-[-2rem] bg-white rounded-2xl shadow-xl p-4 sm:p-6">
                <div className="flex gap-4 sm:gap-6">
                  {stats.map((stat) => (
                    <div key={stat.label} className="stat-item text-center">
                      <div
                        className="text-2xl sm:text-3xl font-bold text-[#228B22]"
                        style={{ fontFamily: 'Montserrat, sans-serif' }}
                      >
                        {stat.value}
                      </div>
                      <div className="text-xs text-gray-500 mt-1">{stat.label}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Content Side */}
          <div ref={contentRef} className="order-1 lg:order-2">
            <span
              className="about-label inline-block text-sm font-semibold text-[#228B22] uppercase tracking-wider mb-4"
              style={{ fontFamily: 'Montserrat, sans-serif' }}
            >
              Sobre o QUB
            </span>

            <h2
              className="about-title text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-800 mb-6 leading-tight"
              style={{ fontFamily: 'Montserrat, sans-serif' }}
            >
              <span className="inline-block">Modernizando os</span>{' '}
              <span className="inline-block text-gradient-qub">Serviços</span>{' '}
              <span className="inline-block">de Transporte</span>{' '}
              <span className="inline-block">da Guiné-Bissau</span>
            </h2>

            <p className="about-text text-gray-600 text-base sm:text-lg leading-relaxed mb-4">
              O QUB (Quipux Bissau) é o Centro de Serviços Integrados do Ministério dos
              Transportes e Comunicações, responsável pela digitalização e modernização de
              todos os serviços relacionados ao sistema de transportes do país.
            </p>

            <p className="about-text text-gray-600 text-base leading-relaxed mb-8">
              Nossa missão é proporcionar serviços eficientes, seguros e acessíveis,
              utilizando tecnologia de ponta para simplificar processos e melhorar a
              experiência dos cidadãos.
            </p>

            {/* Features List */}
            <div className="space-y-3 mb-8">
              {features.map((feature) => (
                <div key={feature} className="about-feature flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-[#228B22] flex-shrink-0" />
                  <span className="text-gray-700 text-sm sm:text-base">{feature}</span>
                </div>
              ))}
            </div>

            {/* CTA Button */}
            <Button
              className="bg-[#228B22] hover:bg-[#1A6B1A] text-white px-8 py-6 rounded-full text-base font-semibold transition-all duration-300 hover:scale-105 hover:shadow-xl group"
              style={{ fontFamily: 'Montserrat, sans-serif' }}
            >
              Conheça Nossa História
              <ArrowRight className="ml-2 w-5 h-5 transition-transform group-hover:translate-x-1" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
