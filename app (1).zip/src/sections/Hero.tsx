import { useEffect, useRef } from 'react';
import { ArrowRight, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import gsap from 'gsap';

const Hero = () => {
  const heroRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const subheadlineRef = useRef<HTMLParagraphElement>(null);
  const descriptionRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const hexagonsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Timeline for entrance animations
      const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });

      // Headline animation
      tl.fromTo(
        '.headline-line',
        { clipPath: 'inset(0 100% 0 0)', opacity: 0 },
        { clipPath: 'inset(0 0% 0 0)', opacity: 1, duration: 0.8, stagger: 0.2 }
      );

      // Subheadline
      tl.fromTo(
        subheadlineRef.current,
        { y: 30, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.6 },
        '-=0.3'
      );

      // Description
      tl.fromTo(
        descriptionRef.current,
        { y: 20, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.6 },
        '-=0.3'
      );

      // CTA buttons
      tl.fromTo(
        '.cta-button',
        { scale: 0, opacity: 0 },
        { scale: 1, opacity: 1, duration: 0.5, stagger: 0.15, ease: 'back.out(1.7)' },
        '-=0.2'
      );

      // Floating hexagons
      tl.fromTo(
        '.floating-hex',
        { scale: 0, opacity: 0, rotation: -180 },
        { scale: 1, opacity: 1, rotation: 0, duration: 1, stagger: 0.1, ease: 'power3.out' },
        '-=0.5'
      );

      // Continuous floating animation for hexagons
      gsap.to('.floating-hex', {
        y: '+=15',
        duration: 2,
        ease: 'sine.inOut',
        yoyo: true,
        repeat: -1,
        stagger: {
          each: 0.3,
          from: 'random',
        },
      });

      // Slow rotation for large hexagon
      gsap.to('.large-hex', {
        rotation: 360,
        duration: 60,
        ease: 'none',
        repeat: -1,
      });
    }, heroRef);

    return () => ctx.revert();
  }, []);

  const scrollToServices = () => {
    const element = document.querySelector('#services');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="hero"
      ref={heroRef}
      className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-white via-[#f0f7f0] to-[#fff9e6]"
    >
      {/* Animated Background Mesh */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute inset-0 opacity-30">
          <div
            className="absolute top-0 left-0 w-[800px] h-[800px] rounded-full blur-3xl animate-gradient-shift"
            style={{
              background: 'radial-gradient(circle, rgba(34,139,34,0.3) 0%, transparent 70%)',
              animation: 'float 8s ease-in-out infinite',
            }}
          />
          <div
            className="absolute bottom-0 right-0 w-[600px] h-[600px] rounded-full blur-3xl"
            style={{
              background: 'radial-gradient(circle, rgba(255,215,0,0.2) 0%, transparent 70%)',
              animation: 'float 10s ease-in-out infinite reverse',
            }}
          />
          <div
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full blur-3xl"
            style={{
              background: 'radial-gradient(circle, rgba(220,20,60,0.15) 0%, transparent 70%)',
              animation: 'float 12s ease-in-out infinite',
            }}
          />
        </div>

        {/* Hexagonal Pattern Overlay */}
        <svg className="absolute inset-0 w-full h-full opacity-5" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="hexPattern" x="0" y="0" width="50" height="43.3" patternUnits="userSpaceOnUse">
              <polygon
                points="25,0 50,10.8 50,32.5 25,43.3 0,32.5 0,10.8"
                fill="none"
                stroke="#228B22"
                strokeWidth="0.5"
              />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#hexPattern)" />
        </svg>
      </div>

      {/* Large Rotating Hexagon */}
      <div
        ref={hexagonsRef}
        className="absolute right-[10%] top-1/2 -translate-y-1/2 hidden lg:block"
      >
        <div className="large-hex relative w-[400px] h-[400px]">
          <svg viewBox="0 0 400 400" className="w-full h-full">
            <defs>
              <linearGradient id="largeHexGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#228B22" stopOpacity="0.3" />
                <stop offset="50%" stopColor="#FFD700" stopOpacity="0.2" />
                <stop offset="100%" stopColor="#DC143C" stopOpacity="0.3" />
              </linearGradient>
            </defs>
            <polygon
              points="200,20 380,110 380,290 200,380 20,290 20,110"
              fill="none"
              stroke="url(#largeHexGradient)"
              strokeWidth="2"
            />
          </svg>
        </div>

        {/* Floating Small Hexagons */}
        <div className="floating-hex absolute -top-10 -left-10 w-16 h-16">
          <svg viewBox="0 0 64 64" className="w-full h-full">
            <polygon
              points="32,4 60,18 60,46 32,60 4,46 4,18"
              fill="#228B22"
              fillOpacity="0.2"
            />
          </svg>
        </div>
        <div className="floating-hex absolute -bottom-5 -right-5 w-12 h-12">
          <svg viewBox="0 0 48 48" className="w-full h-full">
            <polygon
              points="24,4 44,14 44,34 24,44 4,34 4,14"
              fill="#FFD700"
              fillOpacity="0.3"
            />
          </svg>
        </div>
        <div className="floating-hex absolute top-1/2 -left-20 w-10 h-10">
          <svg viewBox="0 0 40 40" className="w-full h-full">
            <polygon
              points="20,2 38,11 38,29 20,38 2,29 2,11"
              fill="#DC143C"
              fillOpacity="0.2"
            />
          </svg>
        </div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="max-w-2xl">
          {/* Headline */}
          <div ref={headlineRef} className="mb-6">
            <h1
              className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-800 leading-tight"
              style={{ fontFamily: 'Montserrat, sans-serif' }}
            >
              <span className="headline-line block" style={{ clipPath: 'inset(0 0% 0 0)' }}>
                Centro de Serviços
              </span>
              <span
                className="headline-line block text-gradient-qub"
                style={{ clipPath: 'inset(0 0% 0 0)' }}
              >
                Integrados
              </span>
            </h1>
          </div>

          {/* Subheadline */}
          <p
            ref={subheadlineRef}
            className="text-lg sm:text-xl text-[#228B22] font-semibold mb-4"
            style={{ fontFamily: 'Montserrat, sans-serif' }}
          >
            Sistema de Gestão Integrada de Transportes da Guiné-Bissau
          </p>

          {/* Description */}
          <p
            ref={descriptionRef}
            className="text-base sm:text-lg text-gray-600 mb-8 leading-relaxed"
          >
            Modernizamos os serviços de transporte com tecnologia segura, eficiente e
            acessível a todos os cidadãos. Digitalizamos processos para um futuro mais
            conectado.
          </p>

          {/* CTA Buttons */}
          <div ref={ctaRef} className="flex flex-col sm:flex-row gap-4">
            <Button
              onClick={scrollToServices}
              className="cta-button bg-[#228B22] hover:bg-[#1A6B1A] text-white px-8 py-6 rounded-full text-base font-semibold transition-all duration-300 hover:scale-105 hover:shadow-xl group"
              style={{ fontFamily: 'Montserrat, sans-serif' }}
            >
              Conheça Nossos Serviços
              <ArrowRight className="ml-2 w-5 h-5 transition-transform group-hover:translate-x-1" />
            </Button>
            <Button
              variant="outline"
              className="cta-button border-2 border-[#228B22] text-[#228B22] hover:bg-[#228B22] hover:text-white px-8 py-6 rounded-full text-base font-semibold transition-all duration-300"
              style={{ fontFamily: 'Montserrat, sans-serif' }}
            >
              Área do Cidadão
            </Button>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <button
          onClick={scrollToServices}
          className="p-2 rounded-full bg-white/80 hover:bg-white shadow-lg transition-all duration-300 hover:scale-110"
          aria-label="Scroll to services"
        >
          <ChevronDown className="w-6 h-6 text-[#228B22]" />
        </button>
      </div>

      {/* Additional Floating Hexagons */}
      <div className="floating-hex absolute left-[5%] top-[20%] w-20 h-20 hidden md:block">
        <svg viewBox="0 0 80 80" className="w-full h-full">
          <polygon
            points="40,5 75,22.5 75,57.5 40,75 5,57.5 5,22.5"
            fill="none"
            stroke="#228B22"
            strokeWidth="1.5"
            strokeOpacity="0.3"
          />
        </svg>
      </div>
      <div className="floating-hex absolute right-[15%] bottom-[20%] w-14 h-14 hidden md:block">
        <svg viewBox="0 0 56 56" className="w-full h-full">
          <polygon
            points="28,4 52,16 52,40 28,52 4,40 4,16"
            fill="none"
            stroke="#FFD700"
            strokeWidth="1.5"
            strokeOpacity="0.4"
          />
        </svg>
      </div>
    </section>
  );
};

export default Hero;
