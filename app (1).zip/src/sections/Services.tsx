import { useEffect, useRef } from 'react';
import {
  Settings,
  Car,
  Building2,
  Award,
  Fingerprint,
  Monitor,
  ArrowRight,
} from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface ServiceCardProps {
  icon: React.ElementType;
  title: string;
  description: string;
  color: string;
  delay: number;
}

const ServiceCard = ({ icon: Icon, title, description, color, delay }: ServiceCardProps) => {
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        cardRef.current,
        { rotateY: -90, opacity: 0 },
        {
          rotateY: 0,
          opacity: 1,
          duration: 0.6,
          delay,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: cardRef.current,
            start: 'top 85%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, cardRef);

    return () => ctx.revert();
  }, [delay]);

  return (
    <div
      ref={cardRef}
      className="group relative bg-white rounded-2xl p-6 sm:p-8 shadow-lg hover:shadow-2xl transition-all duration-300 card-3d cursor-pointer overflow-hidden"
      style={{ transformStyle: 'preserve-3d', perspective: '1000px' }}
    >
      {/* Background Gradient on Hover */}
      <div
        className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
        style={{
          background: `linear-gradient(135deg, ${color}10 0%, transparent 100%)`,
        }}
      />

      {/* Hexagon Icon Background */}
      <div className="relative mb-6">
        <div className="w-16 h-16 relative flex items-center justify-center">
          <svg viewBox="0 0 64 64" className="absolute inset-0 w-full h-full">
            <polygon
              points="32,4 60,18 60,46 32,60 4,46 4,18"
              fill={color}
              fillOpacity="0.1"
              stroke={color}
              strokeWidth="1.5"
              className="transition-all duration-300 group-hover:fill-opacity-20"
            />
          </svg>
          <Icon
            className="w-7 h-7 relative z-10 transition-all duration-300 group-hover:scale-110"
            style={{ color }}
          />
        </div>
      </div>

      {/* Content */}
      <h3
        className="text-xl font-bold text-gray-800 mb-3 group-hover:text-[#228B22] transition-colors duration-300"
        style={{ fontFamily: 'Montserrat, sans-serif' }}
      >
        {title}
      </h3>
      <p className="text-gray-600 text-sm leading-relaxed mb-4">{description}</p>

      {/* Learn More Link */}
      <div className="flex items-center text-sm font-medium text-[#228B22] opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-300">
        <span>Saiba mais</span>
        <ArrowRight className="w-4 h-4 ml-1 transition-transform group-hover:translate-x-1" />
      </div>

      {/* Border Glow */}
      <div
        className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
        style={{
          boxShadow: `inset 0 0 0 2px ${color}40`,
        }}
      />
    </div>
  );
};

const Services = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLDivElement>(null);

  const services = [
    {
      icon: Settings,
      title: 'Sistema de Gestão Integrada',
      description:
        'Plataforma centralizada para administração eficiente de todos os processos de transporte, com dashboard administrativo e relatórios em tempo real.',
      color: '#228B22',
    },
    {
      icon: Car,
      title: 'Novo Sistema de Matrícula',
      description:
        'Registro e renovação de matrículas de veículos de forma rápida e segura, com agendamento online e emissão de certificados digitais.',
      color: '#FFD700',
    },
    {
      icon: Building2,
      title: 'Balcão Único dos Transportes',
      description:
        'Atendimento integrado presencial e digital para todos os serviços, com fila virtual e acompanhamento de processos.',
      color: '#DC143C',
    },
    {
      icon: Award,
      title: 'Certificado de Matrícula',
      description:
        'Emissão digital de certificados com validação por QR Code, garantindo autenticidade e segurança dos documentos.',
      color: '#228B22',
    },
    {
      icon: Fingerprint,
      title: 'Documentos Biométricos Seguros',
      description:
        'Identificação segura com captura biométrica e validação facial, utilizando tecnologia de ponta para proteção de dados.',
      color: '#FFD700',
    },
    {
      icon: Monitor,
      title: 'Serviços Digitalizados',
      description:
        'Portal do cidadão para acesso online a todos os serviços, com consulta de processos e notificações em tempo real.',
      color: '#DC143C',
    },
  ];

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Title animation
      gsap.fromTo(
        '.title-word',
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          stagger: 0.1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: titleRef.current,
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );

      // Hexagon accent animation
      gsap.fromTo(
        '.hex-accent',
        { strokeDashoffset: 100 },
        {
          strokeDashoffset: 0,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: titleRef.current,
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="services"
      ref={sectionRef}
      className="relative py-20 sm:py-28 bg-white overflow-hidden"
    >
      {/* Background Decoration */}
      <div className="absolute inset-0 pointer-events-none">
        <div
          className="absolute top-0 right-0 w-[400px] h-[400px] rounded-full blur-3xl opacity-20"
          style={{
            background: 'radial-gradient(circle, rgba(34,139,34,0.3) 0%, transparent 70%)',
          }}
        />
        <div
          className="absolute bottom-0 left-0 w-[300px] h-[300px] rounded-full blur-3xl opacity-20"
          style={{
            background: 'radial-gradient(circle, rgba(255,215,0,0.3) 0%, transparent 70%)',
          }}
        />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div ref={titleRef} className="text-center mb-16">
          <div className="flex items-center justify-center gap-4 mb-4">
            <svg width="40" height="20" viewBox="0 0 40 20" className="hex-accent">
              <line
                x1="0"
                y1="10"
                x2="40"
                y2="10"
                stroke="#228B22"
                strokeWidth="2"
                strokeDasharray="100"
                strokeDashoffset="100"
              />
            </svg>
            <span
              className="title-word text-sm font-semibold text-[#228B22] uppercase tracking-wider"
              style={{ fontFamily: 'Montserrat, sans-serif' }}
            >
              O que oferecemos
            </span>
            <svg width="40" height="20" viewBox="0 0 40 20" className="hex-accent">
              <line
                x1="0"
                y1="10"
                x2="40"
                y2="10"
                stroke="#228B22"
                strokeWidth="2"
                strokeDasharray="100"
                strokeDashoffset="100"
              />
            </svg>
          </div>
          <h2
            className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-800 mb-4"
            style={{ fontFamily: 'Montserrat, sans-serif' }}
          >
            <span className="title-word inline-block">Nossos</span>{' '}
            <span className="title-word inline-block text-gradient-qub">Serviços</span>
          </h2>
          <p className="title-word text-gray-600 max-w-2xl mx-auto text-base sm:text-lg">
            Soluções integradas para modernizar o sistema de transportes da Guiné-Bissau,
            tornando os serviços mais acessíveis e eficientes.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {services.map((service, index) => (
            <ServiceCard
              key={service.title}
              {...service}
              delay={index * 0.1}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
