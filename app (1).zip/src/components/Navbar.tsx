import { useState, useEffect } from 'react';
import { Menu, X, User } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Início', href: '#hero' },
    { name: 'Serviços', href: '#services' },
    { name: 'Sobre', href: '#about' },
    { name: 'Contactos', href: '#contact' },
  ];

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isScrolled
            ? 'glassmorphism py-3'
            : 'bg-transparent py-5'
        }`}
        style={{
          transitionTimingFunction: 'var(--ease-hex-in)',
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <a
              href="#hero"
              onClick={(e) => {
                e.preventDefault();
                scrollToSection('#hero');
              }}
              className="flex items-center gap-3 group"
            >
              <div className="relative w-12 h-12 flex items-center justify-center">
                <svg
                  viewBox="0 0 100 100"
                  className="w-full h-full transition-transform duration-500 group-hover:rotate-12"
                  style={{ transitionTimingFunction: 'var(--ease-elastic)' }}
                >
                  <defs>
                    <linearGradient id="hexGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#228B22" />
                      <stop offset="50%" stopColor="#FFD700" />
                      <stop offset="100%" stopColor="#DC143C" />
                    </linearGradient>
                  </defs>
                  <polygon
                    points="50,5 95,27.5 95,72.5 50,95 5,72.5 5,27.5"
                    fill="none"
                    stroke="url(#hexGradient)"
                    strokeWidth="4"
                  />
                  <text
                    x="50"
                    y="55"
                    textAnchor="middle"
                    className="text-xl font-bold"
                    fill="#228B22"
                    style={{ fontFamily: 'Montserrat, sans-serif' }}
                  >
                    QUB
                  </text>
                </svg>
              </div>
              <div className="hidden sm:block">
                <span
                  className={`text-lg font-bold transition-colors duration-300 ${
                    isScrolled ? 'text-gray-800' : 'text-gray-800'
                  }`}
                  style={{ fontFamily: 'Montserrat, sans-serif' }}
                >
                  QUIPUX BISSAU
                </span>
              </div>
            </a>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-8">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={(e) => {
                    e.preventDefault();
                    scrollToSection(link.href);
                  }}
                  className={`text-sm font-medium underline-grow transition-colors duration-200 ${
                    isScrolled ? 'text-gray-700' : 'text-gray-700'
                  } hover:text-[#228B22]`}
                  style={{ fontFamily: 'Montserrat, sans-serif' }}
                >
                  {link.name}
                </a>
              ))}
            </div>

            {/* CTA Button */}
            <div className="hidden md:block">
              <Button
                className="bg-[#228B22] hover:bg-[#1A6B1A] text-white px-6 py-2 rounded-full font-medium transition-all duration-300 hover:scale-105 hover:shadow-lg"
                style={{
                  fontFamily: 'Montserrat, sans-serif',
                  transitionTimingFunction: 'var(--ease-bounce)',
                }}
              >
                <User className="w-4 h-4 mr-2" />
                Área do Cidadão
              </Button>
            </div>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              aria-label="Toggle menu"
            >
              {isMobileMenuOpen ? (
                <X className="w-6 h-6 text-gray-700" />
              ) : (
                <Menu className="w-6 h-6 text-gray-700" />
              )}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      <div
        className={`fixed inset-0 z-40 md:hidden transition-all duration-500 ${
          isMobileMenuOpen ? 'opacity-100 visible' : 'opacity-0 invisible'
        }`}
        style={{ transitionTimingFunction: 'var(--ease-smooth)' }}
      >
        {/* Backdrop */}
        <div
          className="absolute inset-0 bg-black/50 backdrop-blur-sm"
          onClick={() => setIsMobileMenuOpen(false)}
        />

        {/* Menu Panel */}
        <div
          className={`absolute right-0 top-0 h-full w-80 bg-white shadow-2xl transform transition-transform duration-500 ${
            isMobileMenuOpen ? 'translate-x-0' : 'translate-x-full'
          }`}
          style={{ transitionTimingFunction: 'var(--ease-hex-in)' }}
        >
          <div className="p-6 pt-20">
            <div className="flex flex-col gap-4">
              {navLinks.map((link, index) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={(e) => {
                    e.preventDefault();
                    scrollToSection(link.href);
                  }}
                  className="text-lg font-medium text-gray-700 hover:text-[#228B22] py-3 border-b border-gray-100 transition-all duration-300 hover:pl-2"
                  style={{
                    fontFamily: 'Montserrat, sans-serif',
                    animationDelay: `${index * 100}ms`,
                  }}
                >
                  {link.name}
                </a>
              ))}
              <Button
                className="mt-4 bg-[#228B22] hover:bg-[#1A6B1A] text-white w-full py-3 rounded-full font-medium"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                <User className="w-4 h-4 mr-2" />
                Área do Cidadão
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Navbar;
